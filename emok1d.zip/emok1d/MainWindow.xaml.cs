﻿using Microsoft.Win32;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Documents.Serialization;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace emok1d
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {//СОХРАНЕНИЕ СПИСКА В ФАЙЛ
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Текстовые файлы (*.txt)|*.txt|Скрипты (*.sql)|*.sql|Документы (*.docx)|*.docx";
            if (sfd.ShowDialog() == true)
            {
                string FilePath = sfd.FileName;

                StreamWriter swriter = new StreamWriter(FilePath);

                foreach (string item in LstDataFile1.Items) 
                {
                    swriter.WriteLine(item);
                }
                swriter.Close();
                MessageBox.Show($"Данные сохранены в файл {FilePath}");
            }
            else
            {
                MessageBox.Show($"Пользователь отказался от окна сохранения");
            }
        }

        private void BtnOpen_Click(object sender, RoutedEventArgs e)
        { //добавление файла
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Текстовые файлы (*.txt)|*.txt|Скрипты (*.sql)|*.sql|Документы (*.docx)|*.docx";
            if (ofd.ShowDialog() == true)
            {
                string FilePath = ofd.FileName;
                StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8);

                while (!sreader.EndOfStream)//пока не конеец потока
                {
                    string line = sreader.ReadLine();
                    LstDataFile2.Items.Add(line);
                }
                sreader.Close();
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        { //добавления текста
            string line = box1.Text;
            LstDataFile1.Items.Add(line);
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        { //удаление текста
            if (LstDataFile1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выделите текст для удаления из списка.", "Предупреждение");
            }
            else
            { 
                while (LstDataFile1.SelectedItems.Count > 0)
                {
                    LstDataFile1.Items.Remove(LstDataFile1.SelectedItems[0]);
                }    
            }
            
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {//очищение всего
            LstDataFile1.Items.Clear();
            LstDataFile2.Items.Clear();
        }
    }
}